//get_video_player and remove it
var udpf_video= document.getElementById('udpf-video-player');
var udpf_video_url=udpf_video.src;
udpf_video.remove();

var video_player_dom='<div id="udpf"><video id="udpf-video-player" autoplay=""></video>'+
'<div id="udpf_video_player_controls" class="udpf_video_player_controls"  >'+

      '<!-- <lable id="udpf_video_player_title">hum tum</lable> -->'+
      
      
      '<div id="udpf_video_player_center_pp">'+
      '<!--<div id="udpf_video_player_center_pp_button" class="play" onclick="plaay()" ></div>-->'+
      '</div>'+
      '<div id="udpf_video_player_controls_control_bar_toggler" onclick="control_bar_popup()" ><img src="logo.png" width="60px" height="60px"> </div>'+
      '<div id="udpf_video_player_controls_control">'+
           '<div id="udpf_video_player_timeline">'+
              '<div id="udpf_video_player_playprogress"></div>'+
              '<!--<div id="udpf_video_player_playhead" ></div>-->'+
              '<div id="udpf_video_player_bufffers" ></div>'+
            '</div>'+
         
            '<div id="udpf_video_player_pButton" class="play" onclick="plaay()"></div>'+
            '<div id="udpf_video_player_timeupdate" class="" >0:0/0:0</div>'+
            '<div id="udpf_video_player_volume_Popup" style="display: none;" class="volume_popup">'+
            '<span"> <input type="range" min="0" max="100" value="50" class="volume_slider" id="volume_range"><p>Value: <span id="volume_value"></span></p></span>'+
            '</div>'+
            '<div id="udpf_video_player_volume" onclick="volume_popup()"></div>'+
            '<div id="udpf_video_player_setting_Popup" style="display: none;" class="setting_popup">'+
             '<span"> <input type="range" min="-50" max="200" value="100" class="playbackrate_slider" id="playbackrate_range"><p>Value: <span id="playbackrate_value"></span></p></span>'+
            '</div>'+
            '<div id="udpf_video_player_setting" onclick="setting_popup()"></div>'+
            '<div id="udpf_video_player_fst" class="udpf_video_player_fst_expand" ></div>'+
       '</div>'+
      
      
'</div></div>';
echo (video_player_dom,"id","udpf-video-player-container");

//////////////////////////////////////////////////////// initial setting
var udpf_video= document.getElementById('udpf-video-player');

////////////////////////////////////////////////////// eventlistener and function


// fade out udpf_video_player_controls when mouse is not over it after 30 msExitFullscreen

/// mouse over
/*var udpf_video_player_controls = document.getElementById('udpf_video_player_controls');
udpf_video_player_controls.addEventListener("mouseover", function (){
   
   udpf_video_player_controls.className="udpf_video_player_controls_onmoveover";
    
},false);

// mouse out
udpf_video_player_controls.addEventListener("mouseout", function (){
    
setTimeout(function(){
      udpf_video_player_controls.className ="udpf_video_player_controls_onmoveout";
}, 10000);
   
},false);*/
//udpf_video_player_fst
var udpf_video_player_fst= document.getElementById('udpf_video_player_fst');

udpf_video_player_fst.addEventListener('click', function () {
				var el = document.getElementById('udpf');
				toggleFullscreen(el);
			},false);

function toggleFullscreen (el) {
				if(document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement){
					if(document.exitFullscreen){
						document.exitFullscreen();
					}else if(document.mozCancelFullScreen){
						document.mozCancelFullScreen();
					}else if(document.webkitExitFullscreen){
						document.webkitExitFullscreen();
					}else if(document.msExitFullscreen){
						document.msExitFullscreen();
					}
					
					udpf_video_player_fst.className = "udpf_video_player_fst_expand";
					
				}else{
					if(document.documentElement.requestFullscreen){
						el.requestFullscreen();
					}else if(document.documentElement.mozRequestFullScreen){
						el.mozRequestFullScreen();
					}else if(document.documentElement.webkitRequestFullscreen){
						el.webkitRequestFullscreen();
					}else if(document.documentElement.msRequestFullscreen){
						el.msRequestFullscreen();
					}
					udpf_video_player_fst.className = "udpf_video_player_fst_shrink";
				}
			}
			
// play pause on middleof control pannerls

//
var udpf_video_player_pButton= document.getElementById('udpf_video_player_pButton');

udpf_video.onplay = function() {
        udpf_video_player_pButton.className = '';
        udpf_video_player_pButton.className = 'pause';
};
udpf_video.onpause = function() {
        udpf_video_player_pButton.className = '';
        udpf_video_player_pButton.className = 'play';
};

function plaay() {
    if (udpf_video.paused) {
        udpf_video.play();
        udpf_video_player_pButton.className = '';
        udpf_video_player_pButton.className = 'pause';
    } else {
        udpf_video.pause();
        udpf_video_player_pButton.className = '';
        udpf_video_player_pButton.className = 'play';
    }
}


// waiting
var udpf_video_player_center_pp= document.getElementById('udpf_video_player_center_pp');

udpf_video.addEventListener('waiting', function () {

			},false);
			
/// time update			
var udpf_video_player_timeupdate= document.getElementById('udpf_video_player_timeupdate');
udpf_video.addEventListener('timeupdate', function () {
echo(fancyTimeFormat(udpf_video.currentTime)+"/"+fancyTimeFormat(udpf_video.duration) ,"id","udpf_video_player_timeupdate");
			},false);

function setting_popup()
 {
    var x =  document.getElementById("udpf_video_player_setting_Popup");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

// playback rate 
var playbackrate_slider = document.getElementById("playbackrate_range");
var playbackrate_output = document.getElementById("playbackrate_value");
playbackrate_output.innerHTML = playbackrate_slider.value/100;

playbackrate_slider.oninput = function() {
  playbackrate_output.innerHTML = this.value/100;
  udpf_video.playbackRate= this.value/100;
}

function control_bar_popup()
 {
    var x =  document.getElementById("udpf_video_player_controls_control");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

// time line width
var udpf_video_player_timeline=document.getElementById("udpf_video_player_timeline");
var udpf_video_player_playprogress=document.getElementById("udpf_video_player_playprogress");
var udpf_video_player_controls=document.getElementById("udpf_video_player_controls");
var udpf_video_player_controls_control=document.getElementById("udpf_video_player_controls_control");
window.addEventListener("resize",function(){
         timeline_width("px");
},false);
function timeline_width(x)
         {
              var px=udpf_video_player_timeline.offsetWidth;
             var time_line_percentage=100*(px)/udpf_video_player_controls_control.offsetWidth; // in %
             if(x=="px")
             return px;
             if(x=="%")
             return time_line_percentage;
         }
/// time linew update

udpf_video.addEventListener('timeupdate', function() {
    udpf_video_player_playprogress.style.width = (udpf_video.currentTime*100/(udpf_video.duration)) + '%';
},false);

 udpf_video_player_timeline.addEventListener("mousedown",function(e){
                progress_percentage(e.pageX);         
         },false);
         
function progress_percentage(x)
               {
        var percentage =100*(x -udpf_video_player_playprogress.offsetLeft) / udpf_video_player_timeline.offsetWidth;
        udpf_video_player_playprogress.style.width=percentage+"%";
        udpf_video.currentTime=udpf_video.duration*percentage/100;
               }
         //echo (udpf_video_player_controls.offsetLeft);
/// buffer update
var udpf_video_player_bufffers=  document.getElementById("udpf_video_player_bufffers");
udpf_video.addEventListener('timeupdate', function() {
    udpf_video_player_bufffers.style.width = (udpf_video.buffered.end(0)*100/(udpf_video.duration)) + '%';
},false);

// volume

function volume_popup()
 {
    var x =  document.getElementById("udpf_video_player_volume_Popup");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}

var slider = document.getElementById("volume_range");
var output = document.getElementById("volume_value");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
  udpf_video.volume= this.value/100;
}

