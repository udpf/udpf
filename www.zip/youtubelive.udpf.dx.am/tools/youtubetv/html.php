<?php
include ("http://wbut.co.nf/php_function/tools");
$url="https://www.youtube.com/watch?v="+query_data("v");
echo curl_browser($url,"","","","","","cookie");
?>
