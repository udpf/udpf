<?php
include ("http://wbut.co.nf/php_function/tools");
include ("http://wbut.co.nf/php_function/youtube");
function youtube_playlist($id)
{
   // $url='https://www.youtube.com/results?search_query=live&sp=EgJAAQ%253D%253D';
    $url="https://www.youtube.com/playlist?list=".$id;
$op=curl_browser($url,"","","","","",'cookie');
////
$Sp1=strpos($op,'window["ytInitialData"]')+26;
 $ss1=substr($op,$Sp1);
///
$Sp2=strpos($ss1,'window["ytInitialPlayerResponse"]')-6;
$json=substr($ss1,0,$Sp2);
 $arry1=json_decode($json,true);
$arry=$arry1['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents'];

for($i=0;$i<count($arry);$i++)
{
$result['video'][$i]['id']=$arry[$i]['playlistVideoRenderer']['videoId'];
$result['video'][$i]['name']=$arry[$i]['playlistVideoRenderer']['title']['simpleText'];
$result['video'][$i]['img']=$arry[$i]['playlistVideoRenderer']['thumbnail']['thumbnails'][0]['url'];
}
return $result;
}
//$arry=youtube_playlist('PLU12uITxBEPGwcL0DXQwsIWPesljEdnTb');
//print_r($arry);


 
 
 
 


?>
