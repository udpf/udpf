<?php
include "http://wbut.co.nf/php_function/tools";
include "http://wbut.co.nf/php_function/youtube";

$arry=youtube_video(query_data("id"));
//print_r($srry);
if($arry['type']=="live")
header ("Location:".$arry["hls"]);
else
{
?>
    
<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Youtube</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Keywords" content="search,watch,download">
<meta name="Description" content="surf youtube ">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="http://bhuvankumarthakur.co.nf/mycss/mycss_latest.css">
<link rel="stylesheet" href="mycss_latest.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</head>
<body class="mycss-bg">
<!-- header-->
<header class="w3-bar w3-dark-gray w3-top w3-padding" >
  <a class="w3-bar-item w3-button w3-green" href="/"><span class="fa fa-home"></span></a>
  <div class="w3-bar-item w3-btn w3-white">video Details</div>
 <!-- <div class="w3-bar-item w3-button w3-right"><span class="fa fa-envelope"></span></div>
   <button class="w3-bar-item w3-right w3-green"><span class="fa fa-search"> </span> </button>
  <input class="w3-bar-item w3-right w3-btn w3-white" type="text" placeholder="search...." name="search">-->
</header>
<!-- header End -->


<!-- footer-->
<footer class="w3-container w3-grey w3-padding w3-bottom">
<p class="w3-center"><span class="fa fa-copyright"> 2017</p>
</footer>
<!-- footer End-->


<!-- content -->
<div class="mycss-big-container w3-bar w3-light-gray" style="max-width:90%; margin-top:64px; margin-bottom:80px;">
<!-- content start-->

<?php
$arry=$arry['stream'];
$arrlengtho = count($arry);
for($x = 0; $x < $arrlengtho; $x++) 
    {
?>
<div class="w3-bar w3-margin" style="width:600px">
  <div class="w3-bar-item" style="width:75px"><?php echo $arry[$x]['quality_label'];?></div>
  <div class="w3-bar-item w3-green"style="width:100px"><?php $hgffh=explode(";",$arry[$x]['type']); echo $hgffh[0];?></div>
  <a class="w3-bar-item w3-btn w3-red" href="<?php echo $arry[$x]['url'];?>">Download</a>
</div>
<?php
}

?>

<!-- content start End-->
</div>
 <!-- content End -->
</body>
</html>
<?php
}
?>