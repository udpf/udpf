<?php
include "function.php";
if(isset($_GET["id"]))
{
 $id=query_data("id");

}
else
{
 $id="PLU12uITxBEPGwcL0DXQwsIWPesljEdnTb";

}
 $arry=youtube_playlist($id);
  $arry= $arry['video'];
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Youtube Tv</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Keywords" content="Youtube Tv">
<meta name="Description" content="Youtube Tv all channel live here">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="http://bhuvankumarthakur.co.nf/mycss/mycss_latest.css">
<link rel="stylesheet" href="mycss_latest.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<style>
.items{ display:none;
}
#loadMore {
    color:green;
    cursor:pointer;
}
#loadMore:hover {
    color:black;
}
#showLess {
    color:red;
    cursor:pointer;
}
#showLess:hover {
    color:black;
}
</style>
</head>
<body class="mycss-bg">
<!-- header-->
<header class="w3-bar w3-dark-gray w3-top w3-padding" >
  <a class="w3-bar-item w3-button  w3-green" href="/"><span class="fa fa-home"></span></a>
  <div class="w3-bar-item w3-button w3-white">Youtube Tv</div>
</header>
<!-- header End -->


<!-- footer-->
<footer class="w3-container w3-grey w3-bottom w3-padding">
<p class="w3-center"><span class="fa fa-copyright">2017</p>
</footer>
<!-- footer End-->


<!-- content -->
<div class="mycss-big-container w3-light-gray" style="max-width:90%; margin-top:64px; margin-bottom:80px;">
<!-- content Start-->

   <!-- form -->
<div class="w3-panel ">
<input id="search" class="w3-bar-item w3-btn w3-white" type="text" placeholder="search...." name="search" autocomplete="off"> 
</div>

	<!--form End-->

		<!--Search Result-->
<div id='results'class="w3-container w3-padding w3-margin"></div>

<script>
$(window).load(function(){
        $('#search').keyup(function(){
            var searchField = $('#search').val();
			if(searchField === '')  {
				$('#results').html('');
				return;
			}
			
            var regex = new RegExp(searchField, "i");
            var output = ' ';
            var count = 1;
			 var data='<?php print_r(str_replace("'","",json_encode($arry)));?>';
			  data= JSON.parse(data);
              $.each(data, function(key, val){
                if ((val.name.search(regex) != -1)){
                  output += '<div class="mycss-floating-box w3-white w3-round" style="  float:left; width:125px;height:85px;"><a class=" w3-margin-bottom w3-margin-right" href="youtube_live.php?id='+ val.id + '" ><img  class="img" style="width:125px;height:80px;"  src="'+val.img+'" alt="' + val.name +'">	 </a><div class="w3-container w3-red" style ="width:100%;height:5px"><p> </P></div></div>';        
                  count++;
                }
              });
              output += '';
              $('#results').html(output);
        });
      });
</script>
	<!--Search Result End-->
	<div class="w3-container w3-margin" >
	    <b>Total:</b><?php echo count($arry); ?>
	    	 <div class="w3-container w3-green" style ="width:60px;height:5px">
	     <p>
	     </P>
	 </div>
</div>
<?php
$arry_length=count($arry);
for($x=0; $x < $arry_length; $x++)
{
?>
<div class="mycss-floating-box w3-white w3-round items" style=" float:left; width:125px;height:85px;">
     <a title="<?php echo $arry[$x]["name"]; ?>" href="youtube_live.html?id=<?php echo $arry[$x]["id"]; ?>" target="" >
	 <img  class="img" style="width:125px;height:80px;" src="" data-src="<?php echo $arry[$x]['img']; ?>" alt="<?php echo $arry[$x]["name"]; ?>" >
	 </a>
	 <div class="w3-container w3-green" style ="width:100%;height:5px">
	     <p>
	     </P>
	 </div>
</div>
<?php
}
?>
<!-- lode more /load less-->
<div class="w3-bar w3-center w3-margin" >
	<div id="showLess" class="w3-btn w3-dark-gray"><span class="fa fa-arrow-left"> Less </span></div>
	<div id="loadMore" class="w3-btn w3-dark-gray" >More <span class="fa fa-arrow-right"> </span></div>
</div>
<!-- content start End-->
</div>
 <!-- content End -->
</body>
</html>
<script>
$(document).ready(function () {
    size_items = $(".items").size();
	ditems = 50;
	y=50; // no of items shon on first time
    x=ditems;
			//stop loading image
	for( x=0; x<=50;x++)
			{
    $('.img').eq(x).attr('src',$('.img').eq(x).attr('data-src'));
			}
	$('#showLess').hide();
    $('.items:lt('+x+')').show();
    $('#loadMore').click(function () {
        v=x= (x+y <= size_items) ? x+y : size_items;
		      //stop loading image
	for( x=x-y; x<=v;x++)
			{
    $('.img').eq(x).attr('src',$('.img').eq(x).attr('data-src'));
			}
        $('.items:lt('+x+')').show();
		$('#showLess').show();
      if(x==size_items ||x > size_items)
		 $('#loadMore').hide();
    });
    $('#showLess').click(function () {
        x=(x-y<0) ? ditems: x-y;
        $('.items').not(':lt('+x+')').hide();
		$('#loadMore').show();
      if(x==ditems)
		 $('#showLess').hide();
    });
});
</script>

