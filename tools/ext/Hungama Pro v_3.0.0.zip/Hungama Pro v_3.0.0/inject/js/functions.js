// function arry define
var udpf_hungama={}  ;
// drop down
 udpf_hungama.drop_down_quality= function() {
	var self = this;
	var menuItem = $('<div id="udpf_bit"><strong>Quality</strong><span class="up1"></span></div>').addClass('mycss-dropdown mycss-dropbtn w3-section w3-blue');
	var dropDown = $('<div class="mycss-drop mycss-tr-gray-white"></div>');
	var dropDownList = $('<ul class="mycss-dropdown-content w3-blue " style="list-style-type:none;"></ul>');

	var bitrates = ['hd' ,'high','medium','low','auto'];

	menuItem.find('.up1').first().text("("+localStorage.hcom_audio_qty+")");
	bitrates = bitrates.map(function (rate) {


		var el = $('<li><a>' + rate + '</a></li>');

		if(rate === localStorage.hcom_audio_qty) {
			el.addClass('current');
			el.find('a').first().append('<em class="current">(current)</em>');
		}

		el.on('click', function () {
			localStorage.hcom_audio_qty = rate;
			$(this).parent().find('.current').each(function () {
				$(this).removeClass('current');
				$(this).find('a em').remove();
				$("#udpf_bit").find('.up1').first().text("("+localStorage.hcom_audio_qty+" )");
				udpf_hungama.setcookies("hcom_audio_qty", localStorage.hcom_audio_qty,'365');
			});

			$(this).addClass('current');
			$(this).find('a').first().append('<em class="current">(current)</em>');

			menuItem.removeClass('active');
			menuItem.find('.up1').first().text("("+localStorage.hcom_audio_qty+"  )");

		});
		return el;
	});

	menuItem.hover(function () {
		menuItem.addClass('active');
	},
	
	function () {
		menuItem.removeClass('active');
	});

	dropDownList.append(bitrates);
	dropDown.append(dropDownList);
	menuItem.append(dropDown);
  $('#udpf_qty').append(menuItem);  
  //$('.songInfoMobile').append(menuItem);
}
/*

*/
// set cookies
udpf_hungama.setcookies= function(name,value,day){
        // st cookies for mobile
	 	  var d = new Date();
     d.setTime(d.getTime() + (day * 24 * 60 * 60 * 1000));
     var expires = "expires="+d.toUTCString();
	  document.cookie = name + "=" + value + ";" + expires + ";path=/";
	            // set cookies end
}

// refresh
udpf_hungama.doRefresh=function (){
   	 		// st cookies for mobile
	 	  var d = new Date();
     d.setTime(d.getTime() + (50000000000000 * 24 * 60 * 60 * 1000));
     var expires = "expires="+d.toUTCString();
	 document.cookie = '_hmpl' + "=" +'1'+ ";" + expires + ";path=/";
	document.cookie = '_hvpl' + "=" +'1'+ ";" + expires + ";path=/";
	document.cookie = 'gat' + "=" +'1'+ ";" + expires + ";path=/";
	            // set cookies end
   
   $('#preview_time').attr("value","5000");
	$('.adbanner').remove(); //
	$('#rewardsicon').hide(); // mobile rewardsicon hide
    $('.banner').remove();  //
	 $('#adContainer').remove();  //
     $('.watch-playlist').remove(); // in video player side
	 $( "body" ).removeClass( "sb-android" ); // watch icon
	 // userQuality="good";
	 //print_r(userQuality);
	 //player1Obj.config.playTime=360000;
    $('#smartbanner').remove();
	$('#jw_player_notification').remove();
	//$('#vdo-player').remove(); // remove player
	$( "body" ).removeClass( "video-player-shortfilm" ); // watch icon
	$('#recommended').remove();
	$('#footer_sticky_ad').remove();  // audio player top ads on mobile
	$('.ha_player-settings').remove();  // destop  audio player seeting 
	$(".songInfoMobile").find('#bwidgetmob').remove(); // mobile song hungam content ads
	 //alert("reloded");
	 
    }
// https://www.jiosaavn.com/api.php?__call=webapi.get&token=GQUqRgBDQkk&type=song&includeMetaTags=0&ctx=wap6dot0&api_version=4&_format=json&_marker=0 // song info
	// https://www.jiosaavn.com/api.php?__call=song.generateAuthToken&url=ID2ieOjCrwfgWvL5sXl4B1ImC5QfbsDyfwf4RnS5uYBlxsgGnP8uUMZmxMBuHC%2Fy9ErE%2Br9E9e%2F0HApAKU0K5Rw7tS9a8Gtq&bitrate=64&api_version=4&_format=json&ctx=wap6dot0&_marker=0  // stream info
	// https://www.jiosaavn.com/api.php?__call=reco.getAlbumReco&api_version=4&_format=json&_marker=0&ctx=wap6dot0&albumid=20573670 // album detail by id
	// https://www.jiosaavn.com/api.php?__call=webapi.get&token=D4bPGk,PV9o_&type=album&includeMetaTags=0&ctx=wap6dot0&api_version=4&_format=json&_marker=0  // album token

 udpf_hungama.album=function (id){
	//alert(print_r(id));
	var url="https://www.hungama.com/audio-player-data/album/"+id['3']+"?_country=IN";
	var op=js_browser(url);
	op= op.trim();  
   var  alb_arry= json_decode(op);
  // print_r(alb_arry);
   var tr_arry= alb_arry;
  var  lengths= count(tr_arry);
  alb_arry= alb_arry['0'];
	//alert();
	var output , i ;
    output='<ul class="w3-ul">'+
 
 '<img class="w3-transparent w3-display-center"  width= "100%" src =" ' + alb_arry.img_src.replace("_50x50", "_1000x1000")+' "> '+
  
  '<li class="w3-display-container">'+
 ''+ alb_arry.album_name +'/'+alb_arry.contenttype +'/'+alb_arry.date+ ''+
    '</li>';
    for ( i=0 ;  i < lengths ; i++ )
      {
      	var json=js_browser(tr_arry[i]['file']);
          var arry1=json_decode(json);
		  var song=hungama_song_info_from_alb_play_page(arry1,tr_arry[i]);
    output += '<li class="w3-display-container">'+  song.title +
 ' <span class="udpf_download w3-button w3-display-right w3-blue " > Get It </span>' +
'<span class="w3-hide song-json"> '+  json_encode(song) + '</span>'+
  '  </li>';
        } 
  output += '</ul>' ;
//$("#udpf_result").prepend(output);
echo( output, "id" , "udpf_result");
}
////////////////////////////////////////////////////
udpf_hungama.song=function (id){
	var url="https://www.hungama.com/audio-player-data/track/"+id['3']+"?_country=IN";
	var op=js_browser(url);
	op= op.trim();  
   var  alb_arry= json_decode(op);
  // print_r(alb_arry);
   var tr_arry= alb_arry;
  var  lengths= count(tr_arry);
  alb_arry= alb_arry['0'];
	//alert();
	var output , i ;
    output='<ul class="w3-ul">'+
 
 '<img class="w3-transparent w3-display-center"  width= "100%" src =" ' + alb_arry.img_src.replace("_200x200", "_1000x1000")+' "> '+
  
  '<li class="w3-display-container">'+
 ''+ alb_arry.album_name +'/'+alb_arry.contenttype +'/'+alb_arry.date+ ''+
    '</li>';
    for ( i=0 ;  i < lengths ; i++ )
      {
      	var json=js_browser(tr_arry[i]['file']);
          var arry1=json_decode(json);
		  var song=udpf_hungama.song_info_from_song_page(arry1,tr_arry[i]);
    output += '<li class="w3-display-container">'+  song.title +
 ' <span class="udpf_download w3-button w3-display-right w3-blue " > Get It </span>' +
'<span class="w3-hide song-json"> '+  json_encode(song) + '</span>'+
  '  </li>';
        } 
  output += '</ul>' ;
//$("#udpf_result").prepend(output);
echo( output, "id" , "udpf_result");
}

/////////////////// playlists//////////////////
 udpf_hungama.playlist=function (id){
	var url="https://www.hungama.com/audio-player-data/playlist/"+id['3']+"?_country=IN";
	var op=js_browser(url);
	op= op.trim();  
   var  alb_arry= json_decode(op);
  // print_r(alb_arry);
   var tr_arry= alb_arry;
  var  lengths= count(tr_arry);
  alb_arry= alb_arry['0'];
	//alert();
	var output , i ;
    output='<ul class="w3-ul">'+
 
 '<img class="w3-transparent w3-display-center"  width= "100%" src =" ' + $(".albumDetails").find("img").attr("src").replace("_300x300", "_1000x1000") +' "> '+
  
  '<li class="w3-display-container">'+
 ''+ alb_arry.album_name +'/'+alb_arry.contenttype +'/'+alb_arry.date+ ''+
    '</li>';
  for ( i=0 ;  i < lengths ; i++ )
      {
      	var json=js_browser(tr_arry[i]['file']);
          var arry1=json_decode(json);
		  var song=hungama_song_info_from_alb_play_page(arry1,tr_arry[i]);
    output += '<li class="w3-display-container">'+  song.title +
 ' <span class="udpf_download w3-button w3-display-right w3-blue " > Get It </span>' +
'<span class="w3-hide song-json"> '+  json_encode(song) + '</span>'+
  '  </li>';
        } 
  output += '</ul>' ;
//$("#udpf_result").prepend(output);
echo( output, "id" , "udpf_result");
}
// playlist end    ////////////
// test start  ////////
udpf_hungama.video=function (id){
	var url= $("#videoPlayerObj").attr('src'); 
	/* var  url= "https://www.hungama.com/index.php?c=common&m=get_video_mdn_url " ;
var postdata="content_id="+id[3]+"&action=movie&cnt_type=movie&movie_rights=TVOD-Premium&lang=hindi" ;
var op=js_browser(url, "post", postdata,"","webpage");
	op= op.trim();  
	alert(op);
   url= json_decode(op).stream_url;
   */
	$("#videoPlayerObj").remove(); 
	$("#vdo-player").remove(); 
	var output ;
    output='<video id="bitmovin_player" width="100%" src = '+ url +' controls> </video>';
//$("#udpf_result").append(output);
echo( output, "id" , "udpf_result");
}
/// test start end //////
/// song Download 
udpf_hungama.hungama_song_download= function (json) {
           var song = JSON.parse(json);
			alert(json_encode(song)); 
	  	  //  $(".udpf_mp3_st").text('loading..');
			downloadWithData(song, song.url, function () {
			// $(".udpf_mp3_st").text('done');
			});
		
};


/**
 * Run on Plugin Initialization
 */
var initPlugin = function () {
	downloadStatus.create();
};

$(document).ready(function () {
	initPlugin();
});

///// song download end /////

// song page 
       udpf_hungama.song_info_from_song_page=function(arry1,arry){
		   var song={};
		   song.url=arry1['response']['media_url'];
           song.logo= arry.img_src.replace("_200x200", "_1000x1000") ; // image of played song
		   song.title=arry['song_name'];
		   song.album=arry['album_name'];
		   song.singers=arry['singer_name'];
		   song.year=arry['date'];
		   song.song_id=arry['mediaid'];
		   song.album_id=arry['id_album'];
		   song.lyrist=arry['lyricist'];
		   song.lyrics=arry['lyrics'];
		   song.lable="";
		   song.md=$(".songMusicDirector").find("a").text()
		   song.audio_quality=localStorage.hcom_audio_qty;
		   song.wp=location.href;
		   return song;
};
// playlist  and album page

       hungama_song_info_from_alb_play_page=function(arry1,arry){
		   var song={};
		   song.url=arry1['response']['media_url'];
           song.logo= $(".albumDetails").find("img").attr("src").replace("_300x300", "_1000x1000") ;  // image of played song
		   song.title=arry['song_name'];
		   song.album=arry['album_name'];
		   song.singers=arry['singer_name'];
		   song.year=arry['date'];
		   song.song_id=arry['mediaid'];
		   song.album_id=arry['id_album'];
		   song.lyrist=arry['lyricist'];
		   song.lyrics=arry['lyrics'];
		   song.lable=$(".artist-details1").first().text().trim();          
		   song.md=$(".artist-details").find("a").first().text();  // music directer

		   song.audio_quality=localStorage.hcom_audio_qty;
		   song.wp=location.href;
		   return song;
};
    

/////////////////////////////////////

