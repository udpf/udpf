// Refresh After few Sec
 setInterval(function(){udpf_hungama.doRefresh()}, 5);
 
 // Add model
 var model='<div id="umodel" class="mycss-modal  mycss-tr-gray-white">'+
'<div class="mycss-modal-content udpf_details mycss-tr-gray-white "> '+
'<div id="udpf_udpf" class="w3-blue w3-center" > Mod By-UDPF </div>'+
'<div id="udpf_qty" class="  " >  </div>'+
'<div id="udpf_album" class="w3-blue w3-button" >  Album</div>'+
'<div id="udpf_playlist" class="w3-blue  w3-button" >  Playlist</div>'+
'<div id="udpf_song" class="w3-blue w3-button" >  Song</div>'+
'<div id="udpf_video" class="w3-blue w3-button" > video</div>'+
'<div id="udpf_result" class="w3-section"> Wellcome to Udpf Mod </div>'+
'<div id="udpf_udpf" class="w3-blue w3-center w3-margin-top" > @udpf</div>'+
'</div></div>';

// click me button
var fixbut='<div class="mycss-fixed_button w3-round  w3-blue "> </div>';
$("body").prepend(fixbut);
$("body").append(model);
udpf_hungama.drop_down_quality();

// when button is clicked
$(".mycss-fixed_button").click(function(){
show_hide_byid("umodel");
});
////////////////////// Add model End//////////////////
udpf_hungama.id= function() {return explode("/", window.location.pathname);};

////// when album button is clicked
$("#udpf_album").click(function(){
	var id=udpf_hungama.id();
 if( 'album' === id[1])
 udpf_hungama.album(id);
 else
echo( " Sorry this is not Album Page", "id" , "udpf_result");
  });
 ////// when song button is clicked
$("#udpf_song").click(function(){
	var id=udpf_hungama.id();
 if( 'song' === id[1])
 udpf_hungama.song(id);
 else
echo( " Sorry this is not SongPage", "id" , "udpf_result");
  });
  ////// when playlist button is clicked
$("#udpf_playlist").click(function(){
	var id=udpf_hungama.id();
 if( "playlists"=== id[1])
 udpf_hungama.playlist(id);
 else
echo( " Sorry this is not Playlist Page", "id" , "udpf_result");
  });
  ///////////// test////////
  $("#udpf_video").click(function(){
  	var id=udpf_hungama.id();
 udpf_hungama.video(id);
  });
  
 //////////////download event listner/////////////	
$("#udpf_result").on("click", ".udpf_download",  function(){
    var json=$(this).siblings('.song-json' ).text();
    udpf_hungama.hungama_song_download(json);
});
