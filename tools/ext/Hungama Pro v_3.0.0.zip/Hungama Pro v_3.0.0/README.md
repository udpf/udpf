# Updated JioSaavn Song Downloader Chrome Extension by Ankush(Skilled-Coder)

This Extension lets you download songs right from your browser, Download 320kbps High Quality songs without Saavn pro! 

No need to login :)

* Download specific songs along with album art and all song info

* Download whole playlist in one click

Give a star if you like it

![Screenshot](screenshot.png)
# How to install

* Download Repository as ZIP

![Screenshot](zip.png)

* Extract the zip and make sure to keep it in a safe place, you should not move/delete this folder after installation of this extension!

![Screenshot](load.png)

* Select the folder using load unpacked or simple drag n drop folder

**Enjoy high quality music and awesome JioSaavn Playlists!**

Please post for issues
