# Hungama Pro Chrome song mp3 Downloader Extension

![Picture](https://raw.githubusercontent.com/udpf/Hungama-Pro/master/img/p4.png)
![Picture](https://raw.githubusercontent.com/udpf/Hungama-Pro/master/img/p5.png)
![Picture](https://raw.githubusercontent.com/udpf/Hungama-Pro/master/img/p6.png)
![Picture](https://raw.githubusercontent.com/udpf/Hungama-Pro/master/img/p7.png)
![Picture](https://raw.githubusercontent.com/udpf/Hungama-Pro/master/img/p8.png)
![Picture](https://raw.githubusercontent.com/udpf/Hungama-Pro/master/img/p9.png)
This Extension will allow you to listen or download songs in any quality including HD from https://www.hungama.com. 

## Features

- Supports HD streaming
- ADS free for Destop and mobile.
- Song download unlocked.
- Download songs in HD qualities.
- Download all album song not leaving page.
- Download all Playlist song not leaving page.
- More ease than previous to download song.
-ID3  complite tags.

## How to use it

- You will have a just select qualities from  player quality selecter.

## How to Install it

this extension is currently not hosted in chrome webstore, so you will have to install it manually on chrome. below are the steps

- Download the extension here : [Download](https://github.com/udpf/Hungama-Pro/archive/master.zip)
- Extract the zip file
- Go to chrome extensions page [chrome://extensions/](chrome://extensions/)
- You will see a button called "Load Unpacked Extension.." click that
- Select the extracted folder and press "ok"

Note :-
- The extension will be enabled on development mode. you will have a popup when opening the chrome. press cancel on that popup. you can always enable it again on the chrome extension page.
- To get download or quality slecter let page fully loaded if after it options not appear reload or refresh page again (sorry for this).
