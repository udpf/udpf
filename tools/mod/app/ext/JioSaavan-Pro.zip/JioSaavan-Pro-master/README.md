# Jiosaavn Pro Chrome Extension

![Song Quality Selector](https://raw.githubusercontent.com/udpf/JioSaavan-Pro/master/img/quality.png)
![Song Quality Selector](https://raw.githubusercontent.com/udpf/JioSaavan-Pro/master/img/m1.png)
![Song Quality Selector](https://raw.githubusercontent.com/udpf/JioSaavan-Pro/master/img/m2.png)

This Extension will allow you to listen or stream songs in 320 kbps and 192kbps from jiosaavan.com. 

## Features

- Supports 320kbps
- Supports 192kbps
- ADS free Destop and mobile.
- In mobile songs limit removed

## How to use it

- You will have a just select qualities from  player quality selecter.

## How to Install it

this extension is currently not hosted in chrome webstore, so you will have to install it manually on chrome. below are the steps

- download the extension here : [Download](https://github.com/udpf/JioSaavan-Pro/archive/master.zip)
- extract the zip file
- go to chrome extensions page [chrome://extensions/](chrome://extensions/)
- you will see a button called "Load Unpacked Extension.." click that
- select the extracted folder and press "ok"

Note : the extension will be enabled on development mode. you will have a popup when opening the chrome. press cancel on that popup. you can always enable it again on the chrome extension page.
