//////////////////// player quality setting  mod//////////////////////////////
$(document).ready(function(){
		//////////////////////////
		////////////////////
		///////// player quality setting  mod
		var btn = $('<div class="drop">'+
		'<ol>'+
		'<li class="drop-scroll">'+
		'<h5>Music Quality <a href="http://udpf.dx.am/JioSaavan-pro.html">MOD BY UDPF</a></h5>'+
		'<ol>'+
		'<li><a onclick="Player.setBitrate(320);">Ult HD <em class="small">320 kbps</em><span id="bitrate-320" ></span></a></li>'+
		'<li><a onclick="Player.setBitrate(192);">HD<em class="small">192 kbps</em><span id="bitrate-192" ></span></a></li>'+
		'<li><a onclick="Player.setBitrate(128);">Best <em class="small">128 kbps</em><span id="bitrate-128" ></span></a></li>'+
		'<li><a onclick="Player.setBitrate(64);">Good <em class="small">64 kbps</em><span id="bitrate-64" class=""></span></a></li>'+
		'<a onclick="Player.setBitrate(32);">Fair <em class="small">32 kbps</em><span id="bitrate-32"></span></a></li>'+
		'<li><a onclick="Player.setBitrate(16);">Low <em class="small">16 kbps</em><span id="bitrate-16"></span></a></li><li>'+
		'</ol>'+
		'</li>'+
		'</ol>'+
		'</div>');
        $(".bitrate").find('.drop ').first().remove();
		$(".bitrate").find('.bitrate ').first().append(btn);
		     if(localStorage.bitrate=="320")
			 $("#bitrate-320").addClass("current-bitrate");
		 		if(localStorage.bitrate=="192")
			 $("#bitrate-192").addClass("current-bitrate");
		 		if(localStorage.bitrate=="128")
			 $("#bitrate-128").addClass("current-bitrate");
		 		if(localStorage.bitrate=="64")
			 $("#bitrate-64").addClass("current-bitrate");
		 		if(localStorage.bitrate=="32")
			 $("#bitrate-32").addClass("current-bitrate");
		 		if(localStorage.bitrate=="16")
			 $("#bitrate-16").addClass("current-bitrate");
		 // 
		
	   $('#go-pro-btn').remove();// pro button remover
	   btn='<a id="go-pro-btn" href="http://udpf.dx.am/JioSaavan-pro.html">MOD BY UDPF </a>';
	   $("#header").find('.wrap').first().append(btn);
		///////////////////////////
});
///////////////////////////////////////
//  Set propetis after few sec
   
   function doRefresh(){
	 ///////////////////////////jio Savvan ////////////////////
	 
	 ////////////////////////// Mobile/////////////////////////
	 $('#slide-download-header-home').remove(); // home scree app downlod  button on mobile
    //$('.cPanel-wrap').remove(); // mobile lang tab
	 $('.ad-banner').remove();///// mobile ads
	 $('#login-panel').remove(); // login popup
	 $('.cPanel-wrap').remove();
	 $('#bottom-banner').css("z-index","-1");  //  mobile 5of 5 song  tab
	          // st cookies for mobile
	 	  var d = new Date();
     d.setTime(d.getTime() + (50000000000000 * 24 * 60 * 60 * 1000));
     var expires = "expires="+d.toUTCString();
	  document.cookie = 'song_count' + "=" + '0' + ";" + expires + ";path=/";
	            // set cookies end
   //$('#bottom-banner').css("display","none");
	 ////////////////////////Desktop//////////////////////
	 
	   $('.site-message-container').remove();  // desktop  messgane in clicking on login
       $('.ad').remove();  // desktop ads
	 //$('#idle-unit-curtain').remove();
   	// $('#skin-wrap').remove();  // destop  jio savan bacgrount skin log in ads fields
	   $('#cPanel-shade').remove(); ///////login shade
	 //$('.wrap clr').remove();
     //$('#footer-inner').remove();
	 //$('#brand-col').remove();
     //$('#searchpage_custom_adiframe').remove(); */
	 //////////////////////////////////////////////////////////////////////////////

                                 
                                 
    }
    setInterval(function(){doRefresh()}, 5);
